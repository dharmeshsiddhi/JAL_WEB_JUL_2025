@extends("layout.app") 
@section('inlineStyle')
<style>
    .scroller {
    max-width: 100%;
    }
    .scroller__inner {
    display: flex;
    flex-wrap: wrap;
    }

    .scroller[data-animated="true"] {
    overflow: hidden;
    }

    .scroller[data-animated="true"] .scroller__inner {
    width: max-content;
    flex-wrap: nowrap;
    animation: scroll var(--_animation-duration, 40s)
        var(--_animation-direction, forwards) linear infinite;
    }

    .scroller[data-direction="right"] {
    --_animation-direction: reverse;
    }

    .scroller[data-direction="left"] {
    --_animation-direction: forwards;
    }

    .scroller[data-speed="fast"] {
    --_animation-duration: 20s;
    }

    .scroller[data-speed="slow"] {
    --_animation-duration: 60s;
    }

    @keyframes scroll {
    to {
        transform: translate(calc(-50% - 0.5rem));
    }
    }

    /* general styles */

    :root {
    --clr-neutral-100: hsl(0, 0%, 100%);
    --clr-primary-100: hsl(205, 15%, 58%);
    --clr-primary-400: hsl(215, 25%, 27%);
    --clr-primary-800: hsl(217, 33%, 17%);
    --clr-primary-900: hsl(218, 33%, 9%);
    }

    .tag-list {
    margin: 0;
    padding-inline: 0;
    list-style: none;
    }

    .tag-list li {
    background: var(--clr-primary-400);
    border-radius: 0.5rem;
    box-shadow: 0 0.5rem 1rem -0.25rem var(--clr-primary-900);
    color:#fff;
    }
    #profi_box {
        padding-left: 0 !important;
        background:#f0f5f9;
    }
    .profi_box {
        margin:10px;
        border: 1px solid rgb(11, 114, 199);
        border-radius: 7px;
        background:#f0f5f9;
        height: 420px;
    }
    .profi_thumb {
        margin: 10px;
    }
    .profi_thumb img {
       /* width:95%;*/
        padding: 5px;
        height:290px;
    }
    .profi_cont {
        padding-left: 5px;
        padding-right: 5px;
    }
    .profi_cont p {
        font-size: 13px;
        text-align: center;
    }
    .profi_cont h3 {
        font-size: 17px;
        text-align: center;
        margin-top: 10px;
    }
    .profi_cont a {
        background-color: #028;
        border: none;
        border-radius: 5px;
        display: block;
        margin-top: 5px;
        font-size: 18px !important;
        font-weight: 600;
        padding: 8px 0 8px 0;
    }
</style>
@endsection
@section("page")
            <section class="navsmu">
                <ul style="margin-bottom: -0.6rem;padding-left: 0.1rem;">
                    <li><a target="_blank" href="https://www.youtube.com/@Jalgaonpolice_"> <i class="fa fa-youtube"></i><span>Youtube</span> </a> </li>
                    <li><a target="_blank" href="https://www.instagram.com/jalgaonpolice_/"><i class="fa fa-instagram"></i><span>Instagram</span></a></li>
                    <li><a target="_blank" href="https://www.facebook.com/JalgaonPolice"><i class="fa fa-facebook-f"></i><span style="color:white;">Facebook</span></a></li>
                    <li><a target="_blank" href="https://twitter.com/jalgaonpolice"><i class="fa fa-twitter"></i><span>Twitter</span></a></li>
                    <li><a target="_blank" href="https://wa.me/919490616555"><i class="fa fa-whatsapp"></i><span>Whatsapp</span></a></li>
                </ul>
            </section>
        <!--<div class="preloader">
            <div class="preloaderIn">
                <img class="preloaderLogo first transition" src="{{ asset('images/mahaPolicelLogo2.jpg') }}" title="Maharashtra State Police" alt="Maharashtra State Police">
                <div class="governance ">
                    <h3 class="second transition">{{ __('SPLASH_SCREEN_TITLE') }}</h3>
                    <div class="governanceIn fifth transition mobileView">
                        <img src="{{ asset('images/dg_dattatray_karale.jpg') }}" title="{{ __('SPLASH_SCREEN_DG_DESGN') }}" alt="{{ __('SPLASH_SCREEN_DG_DESGN') }}">
                        <p class="preloader-font">{{ __('SPLASH_SCREEN_DG_NAME') }}</p>
                        <p>{{ __('SPLASH_SCREEN_DG_DESGN') }}</p>
                    </div>
                    <div class="governanceIn fourth transition mobileView">
                        <img src="{{ asset('images/dgp_rashmi_shukla.jpg') }}" title="{{ __('SPLASH_SCREEN_DGP_DESGN') }}" alt="{{ __('SPLASH_SCREEN_DGP_DESGN') }}">
                        <p class="preloader-font">{{ __('SPLASH_SCREEN_DGP_NAME') }}</p>
                        <p>{{ __('SPLASH_SCREEN_DGP_DESGN') }}</p>
                    </div>
                    <div class="governanceIn third transition cmIn">
                        <img src="{{ asset('images/devendra_fadanvis.jpg') }}" title="{{ __('SPLASH_SCREEN_CM_DESGN') }}" alt="{{ __('SPLASH_SCREEN_CM_DESGN') }}">
                        <p class="preloader-font">{{ __('SPLASH_SCREEN_CM_NAME') }}</p>
                        <p>{{ __('SPLASH_SCREEN_CM_DESGN') }}</p>
                    </div>
                    <div class="governanceIn fourth transition desktopView">
                        <img src="{{ asset('images/dgp_rashmi_shukla.jpg') }}" title="{{ __('SPLASH_SCREEN_DGP_DESGN') }}" alt="{{ __('SPLASH_SCREEN_DGP_DESGN') }}">
                        <p class="preloader-font">{{ __('SPLASH_SCREEN_DGP_NAME') }}</p>
                        <p>{{ __('SPLASH_SCREEN_DGP_DESGN') }}</p>
                    </div>
                    <div class="governanceIn fifth transition desktopView">
                        <img src="{{ asset('images/dg_dattatray_karale.jpg') }}" title="{{ __('SPLASH_SCREEN_DG_DESGN') }}" alt="{{ __('SPLASH_SCREEN_DG_DESGN') }}">
                        <p class="preloader-font">{{ __('SPLASH_SCREEN_DG_NAME') }}</p>
                        <p>{{ __('SPLASH_SCREEN_DG_DESGN') }}</p>
                    </div>
                </div>
            </div>
        </div>-->
                <div class="asideSection col9" >
                        <div class="slider_banner">
                            <div id="slider1" class="owl-carousel owl-theme">
                                <div class='item'><img src="{{ asset('spofficefront.jpg') }}" height="440px" class="mobile-height"/></div>
                                <div class='item'><img src="{{ asset('s15.jpeg') }}" height="440px" class="mobile-height"/></div>
                                <div class='item'><img src="{{ asset('sl1.jpg') }}" height="440px" class="mobile-height"/></div>
                                <div class='item'><img src="{{ asset('sl2.jpg') }}" height="440px" class="mobile-height"/></div>
                            </div>
                            <div class="owl-1_sliderbutton">
                                <a id="owlplay-1" class="clr_Darkblue"><i class="fa fa-play" aria-hidden="true"></i>
                                </a><a id="owlstop-1" class="clr_Darkblue"><i class="fa fa-pause" aria-hidden="true"></i>
                                </a>
                            </div>
                        </div>
                </div><div class="asideSection col3" id="profi_box">
                        <div class="profi_box">
                            <div class="profi_thumb" >
                                <img src="{{ asset('sppic/drmaheshwarreddy.jpg') }}" class="section-info__image" alt="SP Harsh Poddar(IPS)" style="box-shadow: 3px 3px 3px 3px rgba(0.3, 0, 0, 0.6);">
                            </div>
                            <div class="profi_cont">
                                <h3 style="text-align: center; margin-top:4px; margin-bottom:5px;font-weight:600;">{{ __('HOME_PAGE_SP_DESK_SP_NAME') }}</h3>
                                <p style="text-align: center; font-weight: 600; margin-top:5px;">{{ __('HOME_PAGE_SP_DESK_SP_DESG') }}</p>
                                <a href="/sp-message" id="spMessageBtn" class="btn btn-primary">{{ __('HOME_PAGE_SP_DESK_BUTTON') }}</a>
                            </div>
                        </div>
                    </div>
                </div>
            <div class="section__title" style="padding: 0px;">
                <style>
                    .elementor-counter .elementor-counter-number-wrapper{display:flex;font-size:69px;font-weight:600;line-height:1}.elementor-counter .elementor-counter-number-prefix,.elementor-counter .elementor-counter-number-suffix{flex-grow:1;white-space:pre-wrap}.elementor-counter .elementor-counter-number-prefix{text-align:right}.elementor-counter .elementor-counter-number-suffix{text-align:left}.elementor-counter .elementor-counter-title{text-align:center;font-size:19px;font-weight:400;line-height:2.5}
                </style>
                <div class="scroller" data-speed="slow">
                    <ul class="tag-list scroller__inner">
                        <li>
                            <div class="elementor-widget-wrap elementor-element-populated" style="height:88px;background-color: #EEC641; transition: background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;width:250px">
                                <div class="elementor-element elementor-element-4b5edbd elementor-widget elementor-widget-counter" data-id="4b5edbd" data-element_type="widget" data-widget_type="counter.default">
                                    <div class="elementor-widget-container" style="margin: 0px 0px 0px 0px;padding: 13px 8px 8px 8px;background-color: #EEC641;border-radius: 13px 13px 13px 13px;">
                                        <div class="elementor-counter">
                                            <div class="elementor-counter-number-wrapper">
                                                <span class="elementor-counter-number-prefix" style="font-size: 26px;"></span>
                                                <span class="elementor-counter-number" style="font-size: 26px; color:#fff">{{ __('HOME_PAGE_HELPLINE_POLICE_NO') }}</span>
                                                <span class="elementor-counter-number-suffix" style="font-size: 26px;"></span>
                                            </div>
                                            <div class="elementor-counter-title" style="color:#fff;font-size:17px;">{{ __('HOME_PAGE_HELPLINE_POLICE_LABEL') }}</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="elementor-widget-wrap elementor-element-populated" style="height:88px;background-color: #163269; transition: background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;width:250px">
                                <div class="elementor-element elementor-element-c8bd8eb elementor-widget elementor-widget-counter" data-id="c8bd8eb" data-element_type="widget" data-widget_type="counter.default">
                                    <div class="elementor-widget-container" style="margin: 0px 0px 0px 0px;padding: 13px 8px 8px 8px;background-color: #163269;border-radius: 13px 13px 13px 13px;">
                                        <div class="elementor-counter">
                                            <div class="elementor-counter-number-wrapper">
                                                <span class="elementor-counter-number-prefix" style="font-size: 26px;"></span>
                                                <span class="elementor-counter-number" style="font-size: 26px; color:#fff">{{ __('HOME_PAGE_HELPLINE_FIRE_NO') }}</span>
                                                <span class="elementor-counter-number-suffix" style="font-size: 26px;"></span>
                                            </div>
                                            <div class="elementor-counter-title" style="color:#fff;font-size:17px;">{{ __('HOME_PAGE_HELPLINE_FIRE_LABEL') }}</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="elementor-widget-wrap elementor-element-populated" style="height:88px;background-color: #EEC641; transition: background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;width:250px">
                                <div class="elementor-element elementor-element-4b6cf69 elementor-widget elementor-widget-counter" data-id="4b6cf69" data-element_type="widget" data-widget_type="counter.default">
                                    <div class="elementor-widget-container" style="margin: 0px 0px 0px 0px;padding: 13px 8px 8px 8px;background-color: #EEC641;border-radius: 13px 13px 13px 13px;">
                                        <div class="elementor-counter">
                                            <div class="elementor-counter-number-wrapper">
                                                <span class="elementor-counter-number-prefix" style="font-size: 26px;"></span>
                                                <span class="elementor-counter-number"style="font-size: 26px; color:#fff">{{ __('HOME_PAGE_HELPLINE_AMBULANCE_NO') }}</span>
                                                <span class="elementor-counter-number-suffix" style="font-size: 26px;"></span>
                                            </div>
                                            <div class="elementor-counter-title" style="color:#fff;font-size:17px;">{{ __('HOME_PAGE_HELPLINE_AMBULANCE_LABEL') }}</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="elementor-widget-wrap elementor-element-populated" style="height:88px;background-color: #163269; transition: background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;width:250px">
                                <div class="elementor-element elementor-element-4b5edbd elementor-widget elementor-widget-counter" data-id="4b5edbd" data-element_type="widget" data-widget_type="counter.default">
                                    <div class="elementor-widget-container" style="margin: 0px 0px 0px 0px;padding: 13px 8px 8px 8px;background-color: #163269;border-radius: 13px 13px 13px 13px;">
                                        <div class="elementor-counter">
                                            <div class="elementor-counter-number-wrapper">
                                                <span class="elementor-counter-number-prefix" style="font-size: 26px;"></span>
                                                <span class="elementor-counter-number" style="font-size: 26px; color:#fff">{{ __('HOME_PAGE_HELPLINE_RAIL_ACCIDENT_NO') }}</span>
                                                <span class="elementor-counter-number-suffix" style="font-size: 26px;"></span>
                                            </div>
                                            <div class="elementor-counter-title" style="color:#fff;font-size:17px;">{{ __('HOME_PAGE_HELPLINE_RAIL_ACCIDENT_LABEL') }}</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="elementor-widget-wrap elementor-element-populated" style="height:88px;background-color: #EEC641; transition: background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;width:250px">
                                <div class="elementor-element elementor-element-c8bd8eb elementor-widget elementor-widget-counter" data-id="c8bd8eb" data-element_type="widget" data-widget_type="counter.default">
                                    <div class="elementor-widget-container" style="margin: 0px 0px 0px 0px;padding: 13px 8px 8px 8px;background-color: #EEC641;border-radius: 13px 13px 13px 13px;">
                                        <div class="elementor-counter">
                                            <div class="elementor-counter-number-wrapper">
                                                <span class="elementor-counter-number-prefix" style="font-size: 26px;"></span>
                                                <span class="elementor-counter-number" style="font-size: 26px; color:#fff">{{ __('HOME_PAGE_HELPLINE_CHILD_NO') }}</span>
                                                <span class="elementor-counter-number-suffix" style="font-size: 26px;"></span>
                                            </div>
                                            <div class="elementor-counter-title" style="color:#fff;font-size:17px;">{{ __('HOME_PAGE_HELPLINE_CHILD_LABEL') }}</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="elementor-widget-wrap elementor-element-populated" style="height:88px;background-color: #163269; transition: background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;width:250px">
                                <div class="elementor-element elementor-element-4b5edbd elementor-widget elementor-widget-counter" data-id="4b5edbd" data-element_type="widget" data-widget_type="counter.default">
                                    <div class="elementor-widget-container" style="margin: 0px 0px 0px 0px;padding: 13px 8px 8px 8px;background-color: #163269;border-radius: 13px 13px 13px 13px;">
                                        <div class="elementor-counter">
                                            <div class="elementor-counter-number-wrapper">
                                                <span class="elementor-counter-number-prefix" style="font-size: 26px;"></span>
                                                <span class="elementor-counter-number" style="font-size: 26px; color:#fff">{{ __('HOME_PAGE_HELPLINE_WOMEN_NO') }}</span>
                                                <span class="elementor-counter-number-suffix" style="font-size: 26px;"></span>
                                            </div>
                                            <div class="elementor-counter-title" style="color:#fff;font-size:17px;">{{ __('HOME_PAGE_HELPLINE_WOMEN_LABEL') }}</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="elementor-widget-wrap elementor-element-populated" style="height:88px;background-color: #EEC641; transition: background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;width:250px">
                                <div class="elementor-element elementor-element-c8bd8eb elementor-widget elementor-widget-counter" data-id="c8bd8eb" data-element_type="widget" data-widget_type="counter.default">
                                    <div class="elementor-widget-container" style="margin: 0px 0px 0px 0px;padding: 13px 8px 8px 8px;background-color: #EEC641;border-radius: 13px 13px 13px 13px;">
                                        <div class="elementor-counter">
                                            <div class="elementor-counter-number-wrapper">
                                                <span class="elementor-counter-number-prefix" style="font-size: 26px;"></span>
                                                <span class="elementor-counter-number" style="font-size: 26px; color:#fff">{{ __('HOME_PAGE_HELPLINE_CYBER_NO') }}</span>
                                                <span class="elementor-counter-number-suffix" style="font-size: 26px;"></span>
                                            </div>
                                            <div class="elementor-counter-title" style="color:#fff;font-size:17px;">{{ __('HOME_PAGE_HELPLINE_CYBER_LABEL') }}</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="elementor-widget-wrap elementor-element-populated" style="height:88px;background-color: #163269; transition: background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;width:250px">
                                <div class="elementor-element elementor-element-4b6cf69 elementor-widget elementor-widget-counter" data-id="4b6cf69" data-element_type="widget" data-widget_type="counter.default">
                                    <div class="elementor-widget-container" style="margin: 0px 0px 0px 0px;padding: 13px 8px 8px 8px;background-color: #163269;border-radius: 13px 13px 13px 13px;">
                                        <div class="elementor-counter">
                                            <div class="elementor-counter-number-wrapper">
                                                <span class="elementor-counter-number-prefix" style="font-size: 26px;"></span>
                                                <span class="elementor-counter-number"style="font-size: 26px; color:#fff">{{ __('HOME_PAGE_HELPLINE_SENIOR_NO') }}</span>
                                                <span class="elementor-counter-number-suffix" style="font-size: 26px;"></span>
                                            </div>
                                            <div class="elementor-counter-title" style="color:#fff;font-size:17px;">{{ __('HOME_PAGE_HELPLINE_SENIOR_LABEL') }}</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
            <section class="whats_new">
                <div class="common_container">
                    <div class="row">
                        <div class="col-md-12" id="functionaryID">
                            <div class="Key_Functionary">
                                <div class="minister_box me-5 wow zoomIn" data-wow-delay="0.3s">
                                    <div class="outside">
                                        <div class="inside"><img src="{{ asset('hyd/person/devendra_fadanvis.png') }}" class="key_fun_img" alt="Image of {{ __('SPLASH_SCREEN_CM_NAME') }}" title="{{ __('SPLASH_SCREEN_CM_NAME') }}"></div>
                                    </div>
                                    <div class="cm_name">
                                        <p>{{ __('SPLASH_SCREEN_CM_NAME') }}</p>
                                        <span>{{ __('SPLASH_SCREEN_CM_DESGN') }}</span>
                                    </div>
                                </div>
                                <div class="minister_box me-5 wow zoomIn" data-wow-delay="0.3s">
                                    <div class="outside">
                                        <div class="inside"><img src="{{ asset('hyd/person/dgp_rashmi_shukla.png') }}" class="key_fun_img" alt="Image of {{ __('SPLASH_SCREEN_DGP_NAME') }}" title="{{ __('SPLASH_SCREEN_DGP_NAME') }}"></div>
                                    </div>
                                    <div class="cm_name">
                                        <p>{{ __('SPLASH_SCREEN_DGP_NAME') }}</p>
                                        <span>{{ __('SPLASH_SCREEN_DGP_DESGN') }}</span>
                                    </div>
                                </div>
                                <div class="minister_box me-5 wow zoomIn" data-wow-delay="0.3s">
                                    <div class="outside">
                                        <div class="inside"><img src="{{ asset('hyd/person/dg_dattatray_karale.png') }}" class="key_fun_img" alt="Image of {{ __('SPLASH_SCREEN_DG_NAME') }}" title="{{ __('SPLASH_SCREEN_DG_NAME') }}"></div>
                                    </div>
                                    <div class="cm_name">
                                        <p>{{ __('SPLASH_SCREEN_DG_NAME') }}</p>
                                        <span>{{ __('SPLASH_SCREEN_DG_DESGN') }}</span>
                                    </div>
                                </div>
                                <div class="minister_box me-5 wow zoomIn" data-wow-delay="0.3s">
                                    <div class="outside">
                                        <div class="inside"><img src="{{ asset('hyd/person/drmaheshwarreddy.png') }}" class="key_fun_img" alt="Image of {{ __('HOME_PAGE_SP_DESK_SP_NAME') }}" title="{{ __('HOME_PAGE_SP_DESK_SP_NAME') }}"></div>
                                    </div>
                                    <div class="cm_name">
                                        <p>{{ __('HOME_PAGE_SP_DESK_SP_NAME') }}</p>
                                        <span>{{ __('HOME_PAGE_SP_DESK_SP_DESG') }}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="section-info offer" id="spMessageDiv">
                <div class="section__title">
                    <h2 class="section__titletext" style="color: #FFF;">{{ __('HOME_PAGE_SP_DESK_TITLE_FROM') }} <label style="font-size: 1.6rem;font-weight: 700;color: #FFC404;text-align: center;margin-bottom: 1rem;">{{ __('HOME_PAGE_SP_DESK_TITLE_SP_DESK') }}</label></h2>
                    <hr class="section__titlehr" style="background-color: #FFC404;">
                </div>
                <div class="row mx-0 mt-10">
                    <div class="col-md-4"><img style="box-shadow: 3px 3px 3px 3px rgba(0.3, 0, 0, 0.6);" src="{{ asset('sppic/drmaheshwarreddy.jpg') }}" alt="SP" class="section-info__image"></div>
                    <div class="col-md-8">
    <p class="section-info__paragraph" style="font-family: 'Poppins', 'sans-serif'; font-size: 1rem; line-height: 1.7;text-indent: 40px;">
    {{ __('HOME_PAGE_SP_DESK_PARA_1') }}
    </p><br>
    <p class="section-info__paragraph" style="font-family: 'Poppins', 'sans-serif'; font-size: 1rem; line-height: 1.7;text-indent: 40px;">
    {{ __('HOME_PAGE_SP_DESK_PARA_2') }}
    </p>
    <p class="section-info__from mt-20" style="font-family: 'Poppins', 'sans-serif'; font-weight: 700;">{{ __('HOME_PAGE_SP_DESK_SP_NAME') }}</p>
    <p class="section-info__from mt-10" style="font-family: 'Poppins', 'sans-serif'; font-weight: 700;">{{ __('HOME_PAGE_SP_DESK_SP_DESG') }}</p>
</div>

                </div>
            </section>
            <section class="key_fun_section">
                <div class="container_common">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 text-center">
                            <div class="section__title">
                                <h2 class="section__titletext" style="color: rgb(10, 36, 99);">{{ __('HOME_PAGE_SP_DESK_TITLE_FROM') }} <label style="font-size: 1.6rem;font-weight: 700;color: #FFC404;text-align: center;margin-bottom: 1rem;">{{ __('HOME_PAGE_SP_DESK_TITLE_SP_DESK') }}</label></h2>
                                <hr class="section__titlehr" style="background-color: #FFC404;">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="Key_functionary">
                                <div class="Key_functionary_box">
                                    <ul>
                                        <li class="cm_name1">
                                            <svg class="team-shape" xmlns="http://www.w3.org/2000/svg" width="220" height="220" viewBox="0 0 327 337" fill="none">
                                                <path d="M158.167 331C158.167 333.946 160.555 336.333 163.5 336.333C166.446 336.333 168.833 333.946 168.833 331C168.833 328.054 166.446 325.667 163.5 325.667C160.555 325.667 158.167 328.054 158.167 331ZM158.167 6C158.167 8.94552 160.555 11.3333 163.5 11.3333C166.446 11.3333 168.833 8.94552 168.833 6C168.833 3.05448 166.446 0.666667 163.5 0.666667C160.555 0.666667 158.167 3.05448 158.167 6ZM325 167.5C325 257.254 253.238 330 163.5 330V332C254.359 332 327 258.343 327 167.5H325ZM2.00012 167.5C2.00012 77.7618 73.7458 7 163.5 7V5C72.6574 5 0.00012207 76.6411 0.00012207 167.5H2.00012Z" fill="#1a6ed2"></path>
                                            </svg>
                                            <div class="key_border"><span><img src="{{ asset('sppic/drmaheshwarreddy.jpg') }}" alt=""></span></div>
                                            <h5>{{ __('HOME_PAGE_SP_DESK_SP_NAME') }}</h5>
                                            <h6>{{ __('HOME_PAGE_SP_DESK_SP_DESG') }}</h6>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <p class="" style="font-family: 'Poppins', 'sans-serif';font-size: 1rem;text-align: justify;line-height:2em;">{{ __('HOME_PAGE_SP_DESK_PARA_1') }}</p>
                            <p class="" style="font-family: 'Poppins', 'sans-serif';font-size: 1rem;text-align: justify;line-height:2em;">{{ __('HOME_PAGE_SP_DESK_PARA_2') }}</p>
                        </div>
                    </div>
                </div>
            </section>
             <div class="section__title" style="padding-bottom: 0px;background-color:rgb(242, 242, 242);">
            <h2 class="section__titletext" style="color: rgb(10, 36, 99);">{{ __('HOME_PAGE_SOCIAL_MEDIA_TITLE_SOCIAL') }} <label style="font-size: 1.6rem;font-weight: 700;color: #FFC404;text-align: center;margin-bottom: 1rem;">{{ __('HOME_PAGE_SOCIAL_MEDIA_TITLE_MEDIA') }}</label></h2>
            <hr class="section__titlehr" style="background-color: rgb(10, 36, 99);">
        </div>
        <div class="gutterSpace" style="background-color:rgb(242, 242, 242);">
            <div class="trending-social-section" id="trending-social-section">
                <div class="container11">
                    <div class="social-content">
                        <div class="view view-trending-social-media view-id-trending_social_media view-display-id-block view-dom-id-fbc221b922a5d4a507064897939429cb">
                            <div class="view-content row">
                                <div class="col-md-6 col-sm-6 pc-padding">
                                    <div class="views-row views-row-1 views-row-odd views-row-first">
                                        <div class="row1 Twitter">
                                            <div class="social-box-wrapper">
                                                <h2 style="background: linear-gradient(to left, #494F55, #000000);color:#fff"><i></i>Twitter</h2>
                                                <div class="details">
                                                    <div class="twitter-tweet twitter-tweet-rendered" style="display: flex; max-width: 550px; width: 100%; margin-top: 10px; margin-bottom: 10px;">
                                                        <iframe id="twitter-widget-0" scrolling="no" frameborder="0" allowtransparency="true" allowfullscreen="true" class="" title="X Post" src="https://syndication.twitter.com/srv/timeline-profile/screen-name/jalgaonpolice?dnt=false&amp;embedId=twitter-widget-0&amp;features=eyJ0ZndfdGltZWxpbmVfbGlzdCI6eyJidWNrZXQiOltdLCJ2ZXJzaW9uIjpudWxsfSwidGZ3X2ZvbGxvd2VyX2NvdW50X3N1bnNldCI6eyJidWNrZXQiOnRydWUsInZlcnNpb24iOm51bGx9LCJ0ZndfdHdlZXRfZWRpdF9iYWNrZW5kIjp7ImJ1Y2tldCI6Im9uIiwidmVyc2lvbiI6bnVsbH0sInRmd19yZWZzcmNfc2Vzc2lvbiI6eyJidWNrZXQiOiJvbiIsInZlcnNpb24iOm51bGx9LCJ0ZndfZm9zbnJfc29mdF9pbnRlcnZlbnRpb25zX2VuYWJsZWQiOnsiYnVja2V0Ijoib24iLCJ2ZXJzaW9uIjpudWxsfSwidGZ3X21peGVkX21lZGlhXzE1ODk3Ijp7ImJ1Y2tldCI6InRyZWF0bWVudCIsInZlcnNpb24iOm51bGx9LCJ0ZndfZXhwZXJpbWVudHNfY29va2llX2V4cGlyYXRpb24iOnsiYnVja2V0IjoxMjA5NjAwLCJ2ZXJzaW9uIjpudWxsfSwidGZ3X3Nob3dfYmlyZHdhdGNoX3Bpdm90c19lbmFibGVkIjp7ImJ1Y2tldCI6Im9uIiwidmVyc2lvbiI6bnVsbH0sInRmd19kdXBsaWNhdGVfc2NyaWJlc190b19zZXR0aW5ncyI6eyJidWNrZXQiOiJvbiIsInZlcnNpb24iOm51bGx9LCJ0ZndfdXNlX3Byb2ZpbGVfaW1hZ2Vfc2hhcGVfZW5hYmxlZCI6eyJidWNrZXQiOiJvbiIsInZlcnNpb24iOm51bGx9LCJ0ZndfdmlkZW9faGxzX2R5bmFtaWNfbWFuaWZlc3RzXzE1MDgyIjp7ImJ1Y2tldCI6InRydWVfYml0cmF0ZSIsInZlcnNpb24iOm51bGx9LCJ0ZndfbGVnYWN5X3RpbWVsaW5lX3N1bnNldCI6eyJidWNrZXQiOnRydWUsInZlcnNpb24iOm51bGx9LCJ0ZndfdHdlZXRfZWRpdF9mcm9udGVuZCI6eyJidWNrZXQiOiJvbiIsInZlcnNpb24iOm51bGx9fQ%3D%3D&amp;frame=false&amp;hideBorder=false&amp;hideFooter=false&amp;hideHeader=false&amp;hideScrollBar=false&amp;lang=en&amp;origin=https%3A%2F%2Fwww.jalgaonpolice.gov.in%2F&amp;sessionId=6856b1a2b5025bc3392c5dfe94df44a2461d714a&amp;showHeader=true&amp;showReplies=false&amp;transparent=false&amp;widgetsVersion=2615f7e52b7e0%3A1702314776716" style="position: static; visibility: visible; width: 331px; height: 690px; display: block; flex-grow: 1;" data-tweet-id="1841518342840189311"></iframe></div>
                                                    <script async="" src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
                                                </div>
                                            </div>
                                            <div class="text-center">
                                                <a target="_BLANK" href="https://twitter.com/jalgaonpolice" title="View More" class="bluebtn float-center mt-4 wow slideInUp"  style="background: linear-gradient(to left, #494F55, #000000);color:#fff" data-wow-delay="0.4s">View More</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6 pc-padding">
                                    <div class="views-row views-row-3 views-row-odd">
                                        <div class="row1 Facebook">
                                            <div class="social-box-wrapper">
                                                <h2 style="background: linear-gradient(to left, #0082fb, #163269);color:#fff"><i></i>Facebook</h2>
                                                <div class="details">
                                                    <div class="fb-post fb_iframe_widget" style="display: flex; max-width: 550px; width: 100%; margin-top: 10px; margin-bottom: 10px;">
                                                        <iframe name="f20557366bd327cf5" data-testid="fb:page Facebook Social Plugin" title="fb:page Facebook Social Plugin" frameborder="0" allowtransparency="true" allowfullscreen="true" scrolling="no" allow="encrypted-media" src="https://www.facebook.com/v5.0/plugins/page.php?adapt_container_width=true&amp;app_id=1680330345533928&amp;channel=https%3A%2F%2Fstaticxx.facebook.com%2Fx%2Fconnect%2Fxd_arbiter%2F%3Fversion%3D46%23cb%3Dfc9ff08e3d67cc3bc%26domain%3Dwww.jalgaonpolice.gov.in%26is_canvas%3Dfalse%26origin%3Dhttps%253A%252F%252Fwww.jalgaonpolice.gov.in%252Ff91bed0647c30807d%26relation%3Dparent.parent&amp;container_width=498&amp;height=400&amp;hide_cover=false&amp;href=https%3A%2F%2Fwww.facebook.com%2FJalgaonPolice%2F&amp;locale=en_US&amp;sdk=joey&amp;show_facepile=true&amp;small_header=false&amp;tabs=timeline&amp;width=" style="border: none; visibility: visible; width: 330px; height: 690px;" class=""></iframe>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="text-center">
                                                <a target="_BLANK" href="https://www.facebook.com/JalgaonPolice" title="View More" class="bluebtn float-center mt-4 wow slideInUp" style="background: linear-gradient(to left, #0082fb, #163269);color:#fff" data-wow-delay="0.4s">View More</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
            <div class="section__title" style="padding-bottom: 0px;">
            <h2 class="section__titletext" style="color: rgb(10, 36, 99);">{{ __('HOME_PAGE_CITIZEN_SERVICES_TITLE_CITIZEN') }} <label style="font-size: 1.6rem;font-weight: 700;color: #FFC404;text-align: center;margin-bottom: 1rem;">{{ __('HOME_PAGE_CITIZEN_SERVICES_TITLE_SERVICES') }}</label></h2>
            <hr class="section__titlehr" style="background-color: rgb(10, 36, 99);">
        </div>
            <main class="gutterSpace">
                <div class="asideSection col12 pb-4 option_item">
                    <div class="text-center">
                        <div class="row">
                            <div class="col-lg-2 col-md-3 col-sm-3">
                                <a class="product-thumb-overlay external" href="https://citizen.mahapolice.gov.in/Citizen/Login.aspx" target="_blank">
                                    <img src="{{ asset('hyd/quick/PCC-Online.png') }}" alt="">
                                    <h6><span style="color: white;">{{ __('HOME_PAGE_CITIZEN_SERVICES_LODGE_PETITION') }}</span></h6>
                                </a>
                            </div>
                            <div class="col-lg-2 col-md-3 col-sm-3">
                                <a class="product-thumb-overlay external" href="https://citizen.mahapolice.gov.in/Citizen/MH/SearchView.aspx" target="_blank">
                                    <img src="{{ asset('hyd/quick/missingpersons.png') }}" alt="">
                                    <h6><span style="color: white;">{{ __('HOME_PAGE_CITIZEN_SERVICES_MISSING_PERSON') }}</span></h6>
                                </a>
                            </div>
                            <div class="col-lg-2 col-md-3 col-sm-3">
                                <a class="product-thumb-overlay external" href="https://citizen.mahapolice.gov.in/Citizen/MH/PublishedFIRs.aspx" target="_blank">
                                    <img src="{{ asset('hyd/quick/view_fir.png') }}" class="firimg" alt="">
                                    <h6><span style="color: white;">{{ __('HOME_PAGE_CITIZEN_SERVICES_VIEW_PRINT_FIR') }}</span></h6>
                                </a>
                            </div>
                            <div class="col-lg-2 col-md-3 col-sm-3">
                                <a class="product-thumb-overlay external" href="https://citizen.mahapolice.gov.in/Citizen/MH/SearcgAccusedArrest.aspx" target="_blank">
                                    <img src="{{ asset('hyd/quick/arrest.png') }}" alt="">
                                    <h6><span style="color: white;">{{ __('HOME_PAGE_CITIZEN_SERVICES_ARREST_PARTICULARS') }}</span></h6>
                                </a>
                            </div>
                            <div class="col-lg-2 col-md-3 col-sm-3">
                                <a class="product-thumb-overlay" href="/accident-detail-receipt" target="_self">
                                    <img src="{{ asset('hyd/quick/abandandvehicle.png') }}" alt="">
                                    <h6><span style="color: white;">{{ __('HOME_PAGE_CITIZEN_SERVICES_ACCIDENT_COMPENSATION') }}</span></h6>
                                </a>
                            </div>
                            <div class="col-lg-2 col-md-3 col-sm-3">
                                <a class="product-thumb-overlay external" href="https://passportindia.gov.in/AppOnlineProject/welcomeLink" target="_blank">
                                    <img src="{{ asset('hyd/quick/PassPort.png') }}" alt="">
                                    <h6><span style="color: white;">{{ __('HOME_PAGE_CITIZEN_SERVICES_PASSPORT_VERIFICATION') }}</span></h6>
                                </a>
                            </div>
                            <div class="col-lg-2 col-md-3 col-sm-3">
                                <a class="product-thumb-overlay external" href="https://www.ceir.gov.in/Request/CeirUserBlockRequestDirect.jsp" target="_blank">
                                    <img src="{{ asset('hyd/quick/mobile.png') }}" class="permssnimg" alt="">
                                    <h6><span style="color: white;">{{ __('HOME_PAGE_CITIZEN_SERVICES_STOLEN_MOBILE') }}</span>
                                    </h6>
                                </a>
                            </div>
                            <div class="col-lg-2 col-md-3 col-sm-3">
                                <a class="product-thumb-overlay external" href="https://citizen.mahapolice.gov.in/Citizen/MH/index.aspx" target="_blank">
                                    <img class="meesevaimg" src="{{ asset('hyd/quick/eodb.png') }}" alt="">
                                    <h6><span style="color: white;">{{ __('HOME_PAGE_CITIZEN_SERVICES_CITIZEN_PORTAL') }}</span></h6>
                                </a>
                            </div>
                            <div class="col-lg-2 col-md-3 col-sm-3">
                                <a class="product-thumb-overlay external" href="https://pcs.mahaonline.gov.in/Forms/Home.aspx" target="_blank">
                                    <img src="{{ asset('hyd/quick/PCC.png') }}" alt="">
                                    <h6><span style="color: white;">{{ __('HOME_PAGE_CITIZEN_SERVICES_POLICE_CLEARANCE') }}<br>{{ __('HOME_PAGE_CITIZEN_SERVICES_VERIFICATION_CERTIFICATE') }}</span></h6>
                                </a>
                            </div>
                            <div class="col-lg-2 col-md-3 col-sm-3">
                                <a class="product-thumb-overlay external" href="https://mahatrafficechallan.gov.in/payechallan/PaymentService.htm" target="_blank">
                                    <img class="challanimg" src="{{ asset('hyd/quick/echallan.png') }}" alt="">
                                    <h6><span style="color: white;">{{ __('HOME_PAGE_CITIZEN_SERVICES_E_CHALAN') }}</span></h6>
                                </a>
                            </div>
                            <div class="col-lg-2 col-md-3 col-sm-3">
                                <a class="product-thumb-overlay" href="/recruitments" target="_self">
                                    <img src="{{ asset('hyd/quick/recruitment.png') }}" alt="">
                                    <h6><span style="color: white;">{{ __('HOME_PAGE_CITIZEN_SERVICES_POLICE_RECRUITMENT') }}</span></h6>
                                </a>
                            </div>
                            <div class="col-lg-2 col-md-3 col-sm-3">
                                <a class="product-thumb-overlay external" href="https://citizen.mahapolice.gov.in/Citizen/MH/SearchDeadBodyList.aspx" target="_blank">
                                    <img class="actsimg" src="{{ asset('hyd/quick/deadbody.png') }}" alt="">
                                    <h6><span style="color: white;">{{ __('HOME_PAGE_CITIZEN_SERVICES_UNIDENTIFIED_BODY') }}</span></h6>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
            <div class="section__title" style="padding-bottom: 0px;background-color:rgb(242, 242, 242);">
            <h2 class="section__titletext" style="color: rgb(10, 36, 99);">{{ __('HOME_PAGE_WINGS_TITLE_WINGS_OF') }} <label style="font-size: 1.6rem;font-weight: 700;color: #FFC404;text-align: center;margin-bottom: 1rem;">{{ __('HOME_PAGE_WINGS_TITLE_JALGAON_POLICE') }}</label></h2>
            <hr class="section__titlehr" style="background-color: rgb(10, 36, 99);">
        </div>
            <main class="gutterSpace" style="background-color:rgb(242, 242, 242);">
                <div class="asideSection col12 pb-4 option_item wings">
                    <div class="row">
                        <div class="col-lg-2 col-md-3 col-sm-3">
                            <a class="product-thumb-overlay" href="/local-crime-branch" target="_self">
                                <img src="{{ asset('hyd/wings/Laworder.png') }}" alt="">
                                <h6 style="padding-top: 15%;font-size: 14px;"><span style="color: white;">{{ __('HOME_PAGE_WINGS_LAW_AND_ORDER') }}</span></h6>
                            </a>
                        </div>
                        <div class="col-lg-2 col-md-3 col-sm-3">
                            <a class="product-thumb-overlay" href="/traffic-branch" target="_self">
                                <img src="{{ asset('hyd/wings/traffic_police.png') }}" alt="">
                                <h6 style="padding-top: 15%;font-size: 14px;"><span style="color: white;">{{ __('HOME_PAGE_WINGS_TRAFFIC_WING') }}</span></h6>
                            </a>
                        </div>
                        <div class="col-lg-2 col-md-3 col-sm-3">
                            <a class="product-thumb-overlay" href="/local-crime-branch" target="_self">
                                <img src="{{ asset('hyd/wings/cybercrime.png') }}" alt="">
                                <h6 style="padding-top: 15%;font-size: 14px;"><span style="color: white;">{{ __('HOME_PAGE_WINGS_CYBER_CRIME') }}</span></h6>
                            </a>
                        </div>
                        <div class="col-lg-2 col-md-3 col-sm-3">
                            <a class="product-thumb-overlay" href="/local-crime-branch" target="_self">
                                <img src="{{ asset('hyd/wings/detective-w.png') }}" alt="">
                                <h6 style="padding-top: 15%;font-size: 14px;"><span style="color: white;">{{ __('HOME_PAGE_WINGS_LOCAL_CRIME_BRANCH') }}</span></h6>
                            </a>
                        </div>
                        <div class="col-lg-2 col-md-3 col-sm-3">
                        <a class="product-thumb-overlay" href="/local-crime-branch" target="_self">
                                <img src="{{ asset('hyd/wings/she_team.png') }}" alt="">
                                <h6 style="padding-top: 15%;font-size: 14px;"><span style="color: white;">{{ __('HOME_PAGE_WINGS_SHE_TEAM') }}</span></h6>
                            </a>
                        </div>
                        <div class="col-lg-2 col-md-3 col-sm-3">
                        <a class="product-thumb-overlay" href="/local-crime-branch" target="_self">
                                <img src="{{ asset('hyd/wings/wings-w.png') }}" alt="">
                                <h6 style="padding-top: 15%;font-size: 14px;"><span style="color: white;">{{ __('HOME_PAGE_WINGS_OTHER_WINGS') }}</span></h6>
                            </a>
                        </div>
                    </div>
                </div>
            </main>
            <section class="our_services">
                <div class="common_container">
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <div class="section__title" style="padding-bottom: 0px;">
                                <h2 class="section__titletext" style="color: rgb(10, 36, 99);">{{ __('HOME_PAGE_INT_TITLE_PROGRAM') }} <label style="font-size: 1.6rem;font-weight: 700;color: #FFC404;text-align: center;margin-bottom: 1rem;">{{ __('HOME_PAGE_INT_TITLE_INITIATIVE') }}</label></h2>
                                <hr class="section__titlehr" style="background-color: rgb(10, 36, 99);">
                            </div>
                        </div>
                    </div>
                    <div id="ourservices" class="owl-carousel owl-theme owl-loaded owl-drag">
                        <div class="owl-stage-outer">
                            <div class="owl-stage" style="transform: translate3d(-1753px, 0px, 0px); transition: 1.5s; width: 3800px;">
                                @if(count($initiativeList))
                                    @foreach($initiativeList as $intDetail)
                                        <div class="owl-item">
                                            <a href="javascript:void(0);" class="ourservices wow zoomInDown" data-wow-delay="0.2s" target="_blank" title="Opens in a new window" onclick="return Confirmviewpage();">
                                                <div class="header">
                                                    <div class="thumb">
                                                        <img src="https://panel.jalgaonpolice.gov.in/{{ $intDetail->MINT_Path }}" alt="service" onerror="this.onerror=null;this.src='images/initiative.jpg';">
                                                    </div>
                                                    <div class="overlay-inner wow zoomIn" data-wow-delay="0.6s">
                                                        <div class="icon">
                                                            <img class="icon-img" src="{{ asset('images/inticon.png') }}" alt="Icon">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="details">
                                                    <h3 class="title" style="font-size: 16px;">{{ \Illuminate\Support\Str::limit($intDetail->MINT_Title, 240, $end='...') }}</h3>
                                                </div>
                                            </a>
                                        </div>
                                    @endforeach
                                @endif
                            </div>
                        </div>
                        <div class="owl-nav"><button type="button" role="presentation" class="owl-prev"><span aria-label="Previous">‹</span></button><button type="button" role="presentation" class="owl-next"><span aria-label="Next">›</span></button></div>
                        <div class="owl-dots"><button role="button" class="owl-dot active"><span></span></button><button role="button" class="owl-dot"><span></span></button></div>
                    </div>
                    <div class="row mx-0">
                        <div class="col-md-12 text-center">
                            <a href="/initiatives" class="bluebtn mt-4 wow slideInUp" data-wow-delay="0.4s" title="VIEW ALL">VIEW ALL</a>
                        </div>
                    </div>
                </div>
            </section>
        <section class="HomePhotoGallery">
            <div class="container_common_xl">
                <div class="section__title">
                    <h2 class="section__titletext" style="color: rgb(10, 36, 99);">{{ __('HOME_PAGE_RECENT_EVENTS_TITLE_RECENT') }} <label style="font-size: 1.6rem;font-weight: 700;color: #FFC404;text-align: center;margin-bottom: 1rem;">{{ __('HOME_PAGE_RECENT_EVENTS_TITLE_EVENTS') }}</label></h2>
                    <hr class="section__titlehr" style="background-color: rgb(10, 36, 99);">
                </div>
                <div class="row mx-0">
                    <div class="col-md-1"></div>
                    <div class="col-md-10">
                        <div id="ourgallery" class="owl-carousel owl-theme owl-loaded owl-drag">
                            <div class="owl-stage-outer">
                                <div class="owl-stage" style="transform: translate3d(-1753px, 0px, 0px); transition: 1.5s; width: 3800px;">
                                    @if(count($galleryList))
                                        @foreach($galleryList as $galDetail)
                                            <div class="owl-item">
                                                <a class="home_img_bx" href="{{ asset('sl1.jpg') }}" data-groups="{{ $galDetail->GMN_Title }}" data-fancybox="gallery" data-caption="{{ $galDetail->GMN_Title }}"><img src="{{ asset('sl1.jpg') }}" alt="{{ $galDetail->GMN_Title }}" title="{{ $galDetail->GMN_Title }}"></a>
                                            </div>
                                            <div class="owl-item">
                                                <a class="home_img_bx" href="{{ asset('sl2.jpg') }}" data-groups="{{ $galDetail->GMN_Title }}" data-fancybox="gallery" data-caption="{{ $galDetail->GMN_Title }}"><img src="{{ asset('sl2.jpg') }}" alt="{{ $galDetail->GMN_Title }}" title="{{ $galDetail->GMN_Title }}"></a>
                                            </div>
                                        @endforeach
                                    @endif
                                </div>
                            </div>
                            <div class="owl-nav"><button type="button" role="presentation" class="owl-prev"><span aria-label="Previous">‹</span></button><button type="button" role="presentation" class="owl-next"><span aria-label="Next">›</span></button></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <div class="section__title">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h2 class="section__titletext" style="color: rgb(10, 36, 99);">{{ __('HOME_PAGE_REGISTER_LABEL') }}</h2>
                    <a href="/register-complaint" class="btn btn-primary btn-lg p-10 font-20" tabindex="1" id="submitBtnId1">{{ __('HOME_PAGE_REGISTER_BUTTON') }} &nbsp; <i class="fa fa-hand-o-right"></i></a>
                </div>
            </div>
        </div>
@endsection
@section('inlineScript')
<script>
</script>
@endsection
