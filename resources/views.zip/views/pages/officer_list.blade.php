@extends("layout.app") 
@section('inlineStyle')
@endsection
@section("page")
    <section class="section-notifications">
        <div class="section__title">
            <h2 class="section__titletext" style="color: rgb(10, 36, 99);">@if(Session::get('language') == 'mr') वरिष्ठ पोलीस अधिकारी  @else Senior Police Officer's @endif    </h2>
            <hr class="section__titlehr" style="background-color: rgb(10, 36, 99);">
        </div>
        <div class="row mx-0">
            <div class="col-md-12">
                <div class="row mx-0">
                    @if(count($officerList))
                        @foreach($officerList as $detail)
                            <div class="col-md-4 mb-5">
                                <div class="card">
                                    <div class="senior-officers__image-container" style="background-color: rgb(10, 36, 99);">
                                        <div class="senior-officers__image-mask"></div>
                                        <img src="https://panel.jalgaonpolice.gov.in/{{ $detail->MSO_Photo }}" class="senior-officers__image" alt="Senior Officer" onerror="this.onerror=null;this.src='images/cap.jpg';">
                                        <!-- <img src="{{ asset('images/cap.jpg') }}" class="senior-officers__image" alt="Senior Officer"> -->
                                    </div>
                                    <div class="card-body">
                                        <h3 class="card-title font-weight-bold text-center"> @if(Session::get('language') == 'mr') {{ $detail->MSO_Name_Mr }} @else {{ $detail->MSO_Name }}   @endif      </h3>
                                        <p class="card-text text-center" style="font-family: 'Poppins','sans-serif';">@if(Session::get('language') == 'mr') {{ $detail->MSO_Work_Location_Mr }} @else {{ $detail->MDES_Name }}, {{ $detail->MSO_Work_Location }}   @endif</p>
                                        <hr>
                                     <!--   <p class="card-text">
                                            <a target="_blank" rel="noopener noreferrer" href="tel:@if($detail->MSO_Mobile != '') {{ $detail->MSO_Mobile }} @endif" class="card-link senior-officers__link">
                                                <img src="images/mobSvg.svg" class="ml-1 mr-2" alt="" height="15px">- @if($detail->MSO_Mobile != '') {{ $detail->MSO_Mobile }} @endif
                                            </a>
                                        </p> -->
                                        <p class="card-text">
                                            <a target="_blank" rel="noopener noreferrer" href="tel:@if($detail->MSO_Landline!= '') {{ $detail->MSO_Landline }} @endif" class="card-link senior-officers__link">
                                                <img src="images/lanlandSvg.svg" class="mr-2" alt="" height="15px">@if($detail->MSO_Landline != '') {{ $detail->MSO_Landline }} @endif
                                            </a>
                                        </p>
                                        <p class="card-text">
                                            <a target="_blank" rel="noopener noreferrer" href="mailto:@if($detail->MSO_Email!= '') {{ $detail->MSO_Email }} @endif" class="card-link senior-officers__link">
                                                <img src="images/emailSvg.svg" class="mr-2" alt="" height="15px">@if($detail->MSO_Email != '') {{ $detail->MSO_Email }} @endif
                                            </a>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    @endif
                </div>
            </div>
        </div>
    </section>
@endsection
