@extends("layout.app") 
@section('inlineStyle')
@endsection
@section("page")







    <section class="section-notifications">
        <div class="section__title">
            <h2 class="section__titletext" style="color: rgb(10, 36, 99);">{{ __('LCB_PAGE_TITLE') }}</h2>
            <hr class="section__titlehr" style="background-color: rgb(10, 36, 99);">
        </div>

        <div class="row mx-0">
            <div class="col-md-1"></div>
            <div class="col-md-10">
            <div class="aboutDesc">
                <h3 style="color: rgb(10, 36, 99);font-weight: bold">{{ __('LCB_PAGE_PARA_TITLE') }} :</h3>
                <p class="line-height-2em text-justify"> {{ __('LCB_PAGE_PARA_DESC') }}</p>
                <ul>
                    <li style="padding-bottom: 24px;" class="text-justify"><b> {{ __('LCB_PAGE_MOB_TITLE') }} : </b>{{ __('LCB_PAGE_MOB_DESC') }}</li>
                    <li style="padding-bottom: 24px;" class="text-justify"><b> {{ __('LCB_PAGE_FINGER_TITLE') }} : </b>{{ __('LCB_PAGE_FINGER_DESC') }}</li>
                    <li style="padding-bottom: 24px;" class="text-justify"><b> {{ __('LCB_PAGE_ADS_TITLE') }} : </b>{{ __('LCB_PAGE_ADS_DESC') }}</li>
                    <li style="padding-bottom: 24px;" class="text-justify"><b> {{ __('LCB_PAGE_DCRB_TITLE') }} : </b>{{ __('LCB_PAGE_DCRB_DESC') }}</li>
                </ul>
            </div>
            <div class="col-md-1"></div>
        </div>
    </section>
@endsection