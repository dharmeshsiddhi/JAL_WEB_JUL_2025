@extends("layout.app") 
@section('inlineStyle')
@endsection
@section("page")
    <section class="section-notifications">
        <div class="section__title">
            <h2 class="section__titletext" style="color: rgb(10, 36, 99);">{{ __('DSB_PAGE_TITLE') }}</h2>
            <hr class="section__titlehr" style="background-color: rgb(10, 36, 99);">
        </div>
        <div class="row mx-0">
            <div class="col-md-1"></div>
            <div class="col-md-10">
            <div class="aboutDesc">
                <h3 style="color: rgb(10, 36, 99);font-weight: bold">{{ __('DSB_PAGE_PARA_TITLE') }}</h3>
                <p class="line-height-2em text-justify"> {{ __('DSB_PAGE_PARA_DESC') }}</p>
                <ul>
                    <li class="text-justify" style="padding-bottom: 24px;">{{ __('DSB_PAGE_LIST_1') }}</li>
                    <li class="text-justify" style="padding-bottom: 24px;">{{ __('DSB_PAGE_LIST_2') }}</li>
                    <li class="text-justify" style="padding-bottom: 24px;">{{ __('DSB_PAGE_LIST_3') }}</li>
                    <li class="text-justify" style="padding-bottom: 24px;">{{ __('DSB_PAGE_LIST_4') }}</li>
                    <li class="text-justify" style="padding-bottom: 24px;">{{ __('DSB_PAGE_LIST_5') }}</li>
                    <li class="text-justify" style="padding-bottom: 24px;">{{ __('DSB_PAGE_LIST_6') }}</li>
                    <li class="text-justify" style="padding-bottom: 24px;">{{ __('DSB_PAGE_LIST_7') }}</li>
                    <li class="text-justify" style="padding-bottom: 24px;">{{ __('DSB_PAGE_LIST_8') }}</li>
                    <li class="text-justify" style="padding-bottom: 24px;">{{ __('DSB_PAGE_LIST_9') }}</li>
                    <li class="text-justify" style="padding-bottom: 24px;">{{ __('DSB_PAGE_LIST_10') }}</li>
                    <li class="text-justify" style="padding-bottom: 24px;">{{ __('DSB_PAGE_LIST_11') }}</li>
                    <li class="text-justify" style="padding-bottom: 24px;">{{ __('DSB_PAGE_LIST_12') }}</li>
                    <li class="text-justify" style="padding-bottom: 24px;">{{ __('DSB_PAGE_LIST_13') }}</li>
                    <li class="text-justify" style="padding-bottom: 24px;">{{ __('DSB_PAGE_LIST_14') }}</li>
                </ul>
            </div>
            <div class="col-md-1"></div>
        </div>
    </section>
@endsection