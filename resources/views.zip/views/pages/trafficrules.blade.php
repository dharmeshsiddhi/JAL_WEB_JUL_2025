@extends("layout.app") 
@section('inlineStyle')
@endsection
@section("page")
    <section class="section-notifications">
        <div class="section__title">
            <h2 class="section__titletext" style="color: rgb(10, 36, 99);">Traffic Rules - What to do Traffic Police stops you !</h2>
            <hr class="section__titlehr" style="background-color: rgb(10, 36, 99);">
        </div>
        <div class="row mx-0">
            <div class="col-md-1"></div>
            <div class="col-md-10">
            <div class="aboutDesc">
                <p align="justify"><span style="font-weight: 400;"> The most important wing of the force charged with security planning as well as functions of intelligence-gathering and counterintelligence. There is City Special Branch (City SB) for the city areas and District Special Branch (DSB) for the districts.</p>
                <h3 style="color: rgb(10, 36, 99);font-weight: bold">Role of DSB</h3>
                <p align="justify"><span style="font-weight: 400;">  The branch deals with the collection, collation and dissemination of intelligence having security and law and order implications. It usually deals with sensitive matters like public agitation, subversive activities which carry potential and real danger to the security of the state and the nation.</p>
                
                
                
            </div>
            <div class="col-md-1"></div>
        </div>
    </section>
@endsection