@extends("layout.app") 
@section('inlineStyle')
@endsection
@section("page")
    <section class="section-notifications">
        <div class="section__title">
            <h2 class="section__titletext" style="color: rgb(10, 36, 99);">{{ __('CONTACT_PAGE_TITLE') }}</h2>
            <hr class="section__titlehr" style="background-color: rgb(10, 36, 99);">
        </div>
        
        
        <div class="row">
            <div class="col-md-1"></div>
            <div class="col-md-10">
                <div class="row">
                    <div class="col-md-6 mb-5">
                        <div class="row data-container m-2">
                            <div class="col-md-12">
                                <h1 class="text-uppercase font-weight-bold mb-4">{{ __('CONTACT_PAGE_NAME') }}</h1>
                                <p class="mb-1rem">
                                    <i class="fa fa-envelope mr-4"></i><span><a href="mailto:sp.jalgaon@mahapolice.gov.in">{{ __('FOOTER_ADDRESS_EMAIL') }}</a></span>
                                </p>
                                <p>
                                    <i class="fa fa-phone mr-4"></i><span><a href="tel:02572220411">{{ __('FOOTER_ADDRESS_PHONE_1') }}</a></span>
                                </p>
                                <p>
                                    <i class="fa fa-phone mr-4"></i><span><a href="tel:02572220411">{{ __('FOOTER_ADDRESS_PHONE_2') }}</a></span>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 mb-5">
                        <div class="row data-container m-2">
                            <div class="col-md-12">
                                <iframe src="https://maps.google.com/maps?q=+Superintendent+of+Police%2C+Jalgaon&t=&z=13&ie=UTF8&iwloc=&output=embed" width="100%" height="300" frameborder="0" aria-hidden="false" tabindex="0" title="Superintendent of Police, Jalgaon, Maharashtra"></iframe>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-1"></div>
        </div>
        
        <div class="section__title">
            <h2 class="section__titletext" style="color: rgb(10, 36, 99);">{{ __('CONTACT_PAGE_TABLE_HEAD') }}</h2>
            <hr class="section__titlehr" style="background-color: rgb(10, 36, 99);">
        </div>
        <div class="row mx-0">
            <div class="col-md-1"></div>
            <form id="form1"></form>
            <div class="col-md-10" id="ajaxResponseData" style="overflow-x:auto;">
                @if($dView == 'Desktop')
                    <table class="table table-hover table-bordered table-responsive-md mt-10">
                        <thead>
                            <tr>
                                <th scope="col" width="">{{ __('CONTACT_PAGE_TABLE_SR') }}</th>
                                <th scope="col" width="19%">{{ __('CONTACT_PAGE_TABLE_NAME') }}</th>
                                <th scope="col" width="">{{ __('CONTACT_PAGE_TABLE_DESIGN') }}</th>
                                <th scope="col" width="">{{ __('CONTACT_PAGE_TABLE_OFFICE_NO') }}</th>
                                <!--<th scope="col" width="15%">{{ __('CONTACT_PAGE_TABLE_MOBILE') }}</th>-->
                                
                            </tr>
                        </thead>
                        <tbody>
                            @php $counter=1; @endphp
                            @if(count($officerList))
                            @foreach($officerList as $detail)
                                <tr>
                                    <td class="v-center">{{$counter}}</td>
                                    <td class="v-center"> @if(Session::get('language') == 'mr') {{ $detail->MSO_Name_Mr }} @else {{ $detail->MSO_Name }}   @endif          </td>
                                    <td class="v-center">
                                    
                                    @if(Session::get('language') == 'mr') {{ $detail->MSO_Work_Location_Mr }} @else {{ $detail->MDES_Name }}, {{ $detail->MSO_Work_Location }}   @endif
                                    </td>
                                    <td><img src="images/lanlandSvg.svg" class="mr-2" alt="" height="15px">@if($detail->MSO_Landline != '') {{ $detail->MSO_Landline }} @endif </td>
                                    <!--<td><img src="images/mobSvg.svg" class="ml-1 mr-2" alt="" height="15px"> @if($detail->MSO_Mobile != '') {{ $detail->MSO_Mobile }} @endif</td>-->
                                    
                                </tr>
                                @php $counter=$counter+1; @endphp  
                            @endforeach
                            @endif
                            @if(count($stationList))
                                @foreach($stationList as $detail)
                                    <tr>
                                        <td class="v-center">{{$counter}}</td>
                                        <td class="v-center"> @if(Session::get('language') == 'mr') {{ $detail->MPS_Incharge_Name_Mr }} @else {{ $detail->MPS_Incharge_Name }}   @endif              </td>
                                        <td class="v-center">@if(Session::get('language') == 'mr') {{ $detail->MPS_Incharge_Post_Mr }} @else {{ $detail->MPS_Incharge_Post }}   @endif, @if(Session::get('language') == 'mr') {{ $detail->MPS_Name_MR }} @else {{ $detail->MPS_Name }} @endif</td>
                                        <td><img src="images/lanlandSvg.svg" class="mr-2" alt="" height="15px">@if($detail->MPS_Phone != '') {{ $detail->MPS_Phone }} @endif </td>
                                        <!--<td><img src="images/mobSvg.svg" class="ml-1 mr-2" alt="" height="15px"> @if($detail->MPS_Incharge_Mobile != '') {{ $detail->MPS_Incharge_Mobile }} @endif</td>-->
                                    </tr>
                                @php $counter=$counter+1; @endphp             
                            @endforeach
                            @endif
                        </tbody>
                    </table>
                @else
                    <div class="table-users">
                        <table class="table11" cellspacing="0">
                            <tr>
                                <th>{{ __('CONTACT_PAGE_TABLE_NAME') }}</th>
                                <th>{{ __('CONTACT_PAGE_TABLE_DESIGN') }}</th>
                                <th>{{ __('CONTACT_PAGE_TABLE_OFFICE_NO') }}</th>
                                <!--<th>{{ __('CONTACT_PAGE_TABLE_MOBILE') }}</th>-->
                            </tr>
                            @php $counter=1; @endphp
                            @if(count($officerList))
                                @foreach($officerList as $detail)
                                    <tr>
                                        <td>@if(Session::get('language') == 'mr') {{ $detail->MSO_Name_Mr }} @else {{ $detail->MSO_Name }}   @endif </td>
                                        <td> @if(Session::get('language') == 'mr') {{ $detail->MSO_Work_Location_Mr }} @else {{ $detail->MDES_Name }}, {{ $detail->MSO_Work_Location }}   @endif</td>
                                        <td><img src="images/lanlandSvg.svg" class="mr-2" alt="" height="15px">@if($detail->MSO_Landline != '') {{ $detail->MSO_Landline }} @endif </td>
                                        <!--<td><img src="images/mobSvg.svg" class="ml-1 mr-2" alt="" height="15px"> @if($detail->MSO_Mobile != '') {{ $detail->MSO_Mobile }} @endif</td>-->
                                    </tr>
                                    @php $counter=$counter+1; @endphp  
                                @endforeach
                            @endif
                            @if(count($stationList))
                                @foreach($stationList as $detail)
                                    <tr>
                                        <td>  @if(Session::get('language') == 'mr') {{ $detail->MPS_Incharge_Name_Mr }} @else {{ $detail->MPS_Incharge_Name }}   @endif</td>
                                        <td class="v-center">@if(Session::get('language') == 'mr') {{ $detail->MPS_Incharge_Post_Mr }} @else {{ $detail->MPS_Incharge_Post }}   @endif, @if(Session::get('language') == 'mr') {{ $detail->MPS_Name_MR }} @else {{ $detail->MPS_Name }} @endif</td>
                                        <td><img src="images/lanlandSvg.svg" class="mr-2" alt="" height="15px">@if($detail->MPS_Phone != '') {{ $detail->MPS_Phone }} @endif </td>
                                        <!--<td><img src="images/mobSvg.svg" class="ml-1 mr-2" alt="" height="15px"> @if($detail->MPS_Incharge_Mobile != '') {{ $detail->MPS_Incharge_Mobile }} @endif</td>-->
                                    </tr>
                                    @php $counter=$counter+1; @endphp             
                                @endforeach
                            @endif
                        </table>
                    </div>
                @endif
            </div>
            <div class="col-md-1"></div>
        </div>
    </section>
@endsection
