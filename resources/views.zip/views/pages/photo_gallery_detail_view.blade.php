@extends("layout.app") 
@section('inlineStyle')
@endsection
@section("page")
    <div class="section__title" style="padding-bottom: 0px;">
        <h2 class="section__titletext" style="color: rgb(10, 36, 99);">{{ __('HOME_PAGE_RECENT_EVENTS_TITLE_RECENT') }} <label style="font-size: 1.6rem;font-weight: 700;color: #FFC404;text-align: center;margin-bottom: 1rem;">{{ __('HOME_PAGE_RECENT_EVENTS_TITLE_EVENTS') }}</label></h2>
        <hr class="section__titlehr" style="background-color: rgb(10, 36, 99);">
    </div>
    <section class="content_body">
    <div class="container_common">
        <div id="DivContent">
            <div class="row" id="PressImgId">
                @if(count($subList))
                    @foreach($subList as $galDetail)
                        <div class="col-lg-3 col-md-3 col-sm-12"><a class="home_img_bx" href="{{ asset('sl1.jpg') }}" data-groups="Image Of Event" data-fancybox="gallery" data-caption="Image Of Event"><img src="{{ asset('sl1.jpg') }}" alt="Image Of Event" title="Image Of Event"></a></div>
                    @endforeach
                @endif
            </div>
        </div>
    </div>
</section>
@endsection
