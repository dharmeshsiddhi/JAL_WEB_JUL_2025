
<div class="homeMainWrapOut">
            <div class="overlay mobileMenuOverlay"></div>
            <div class="overlay innerMenuOverlay"></div>
            <!-- @if($data['segment1'] == '') <div class="feedbackBtn" onclick="openCyberModal()"><p>Cyber Awareness</p></div> @endif -->
            <header class="gutterSpace p-0" data-aos="fade-down">
                <div class="wrapper light-header design-2">
                    <div class="top-nav">
                        <a href="javascript:void(0);" class="humburger-ico" style="font-size: 14px;"><i class="fa fa-bars"></i></a>
                        <a href="javascript:void(0);" class="closemenu" style="font-size: 14px;"><i class="fa fa-times"></i></a>
                        <div class="container11 position-relative">
                            <div class="row">
                                <div class="col-sm-12 col-md-12 col-lg-12 pl-5 pr-5">
                                    <ul class="right-panel float-right">
                                        <li class="dropdown cog-dropdown">
                                            <div class="region region-language-switcher">
                                                <div id="block-languagedropdownswitcher-2" class="block block-lang-dropdown block-language-dropdown-blocklanguage-interface">
                                                    <form class="lang-dropdown-form lang_dropdown_form clearfix language_interface" id="lang_dropdown_form_lang-dropdown-form" data-drupal-selector="lang-dropdown-form-2" action="/" method="post" accept-charset="UTF-8" data-once="cvJqueryValidate" novalidate="novalidate">
                                                        <div class="js-form-item form-item js-form-type-select form-type-select js-form-item-lang-dropdown-select form-item-lang-dropdown-select form-no-label">
                                                            <label for="edit-lang-dropdown-select" class="visually-hidden">Select your language</label>
                                                            <select class="lang-dropdown-select-element form-select clearfix form-control valid" data-lang-dropdown-id="lang-dropdown-form" data-drupal-selector="edit-lang-dropdown-select" id="policeStationBox" name="policeStationBox" aria-invalid="false">
                                                                <option value="" title="{{ __('HOME_PAGE_SEARCH_PS_SELECT_PS') }}">{{ __('HOME_PAGE_SEARCH_PS_SELECT_PS') }}</option>
                                                                @if(count($data['stationList']))
                                                                    @foreach($data['stationList'] as $stnDetail)
                                                                        <option value="{{ $stnDetail->MPS_ID }}">@if(Session::get('language') == 'mr') {{ $stnDetail->MPS_Name_MR }} @else {{ $stnDetail->MPS_Name }} @endif</option>
                                                                    @endforeach
                                                                @endif
                                                            </select>
                                                        </div>
                                                        <input data-drupal-selector="edit-en" type="hidden" name="en" value="/node" class="clearfix form-control">
                                                        <input data-drupal-selector="edit-hi" type="hidden" name="hi" value="/hi/node" class="clearfix form-control">
                                                    </form>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="dropdown cog-dropdown">
                                            <a href="/screen-reader" title="Screen Reader Access" id="screenreader" style="font-size: 14px;">                  
                                            <img src="{{ asset('images/screenreader.png') }}" alt="logo"> 
                                            </a>
                                        </li>
                                        <li class="dropdown cog-dropdown mobile-font-hide">
                                            <a href="javascript:void(0);" onclick="setFontSize('plus');" class="dropdown-toggle" title="Accessibility Dropdown" data-toggle="dropdown" style="font-size: 14px;">
                                            A <sup>+</sup>
                                            </a>
                                        </li>
                                        <li class="dropdown cog-dropdown mobile-font-hide">
                                            <a href="javascript:void(0);" onclick="setFontSize('default');" class="dropdown-toggle" title="Accessibility Dropdown" data-toggle="dropdown" style="font-size: 14px;">
                                            A <sup>&nbsp;</sup>
                                            </a>
                                        </li>
                                        <li class="dropdown cog-dropdown mobile-font-hide">
                                            <a href="javascript:void(0);" onclick="setFontSize('minus');" class="dropdown-toggle" title="Accessibility Dropdown" data-toggle="dropdown" style="font-size: 14px;">
                                            A <sup>-</sup>
                                            </a>
                                        </li>
                                        <li class="dropdown cog-dropdown">
                                            <div class="region region-language-switcher">
                                                <div id="block-languagedropdownswitcher-2" class="block block-lang-dropdown1 block-language-dropdown-blocklanguage-interface">
                                                    <form class="lang-dropdown-form lang_dropdown_form clearfix language_interface" id="lang_dropdown_form_lang-dropdown-form" data-drupal-selector="lang-dropdown-form-2" action="/" method="post" accept-charset="UTF-8" data-once="cvJqueryValidate" novalidate="novalidate">
                                                        <div class="js-form-item form-item js-form-type-select form-type-select js-form-item-lang-dropdown-select form-item-lang-dropdown-select form-no-label">
                                                            <label for="edit-lang-dropdown-select" class="visually-hidden">Select your language</label>
                                                            <select class="lang-dropdown-select-element form-select clearfix form-control valid" data-lang-dropdown-id="lang-dropdown-form" data-drupal-selector="edit-lang-dropdown-select" id="lang_dropdown_select" name="lang_dropdown_select" aria-invalid="false">
                                                                <option value="mr" {{ \Session::get('language') == 'mr' ? 'selected' : '' }}>मराठी</option>
                                                                <option value="en" {{ \Session::get('language') == 'en' ? 'selected' : '' }}>English</option>
                                                            </select>
                                                        </div>
                                                        <input data-drupal-selector="edit-en" type="hidden" name="en" value="/node" class="clearfix form-control">
                                                        <input data-drupal-selector="edit-hi" type="hidden" name="hi" value="/hi/node" class="clearfix form-control">
                                                    </form>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="mid-nav pt-2 pb-2 bg-mid-nav">
                        <div class="container11">
                            <div class="Header">
                                <div class="Header__left">
                                    <a href="/"><img src="{{ asset('images/mlogo.png') }}" alt="Header Logo 1" class="Header__image1"></a>
                                    <div class="Header__title">
                                        <h2>जळगाव जिल्हा पोलीस</h2>
                                        <h2>Jalgaon District Police</h2>
                                    </div>
                                </div>
                                <div class="Header__right"><img src="{{ asset('images/emblem-dark.png') }}" alt="Header Logo 2" class="Header__image2"></div>
                            </div>
                        </div>
                    </div>
                    <div class="menu-bar">
                        <div class="container11">
                            <div class="row">
                                <div class="col-lg-12 p-0">
                                    <div class="menu_wrapper">
                                        <nav class="navbar navbar-expand-lg navbar-light">
                                            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                                                <div class="region region-primary-menu">
                                                    <nav role="navigation" aria-labelledby="block-jalgaon-gov-main-menu-menu" id="block-jalgaon-gov-main-menu" class="col-sm-10 block block-menu navigation menu--main">
                                                        <h2 class="visually-hidden" id="block-jalgaon-gov-main-menu-menu">Main navigation</h2>
                                                        <ul class="nav navbar-nav mr-auto" data-smartmenus-id="17149963338979644">
                                                            <li class="nav-item level-0">
                                                                <a href="/" data-drupal-link-system-path="<front>" class="is-active" style="font-size: 14px;font-weight:600;">{{ __('HEADER_MENU_HOME') }}</a>
                                                            </li>
                                                            <li class="nav-item level-0 dropdown">
                                                                <a href="javascript:void(0);" class="nav-link has-submenu" id="sm-17149963338979644-1" aria-haspopup="true" aria-controls="sm-17149963338979644-2" aria-expanded="false" style="font-size: 14px;font-weight:600;">{{ __('HEADER_MENU_ABOUT_US_ABOUT') }}</a>
                                                                <ul class="dropdown-menu sm-nowrap" id="sm-17149963338979644-2" role="group" aria-hidden="true" aria-labelledby="sm-17149963338979644-1" aria-expanded="false" style="width: auto; min-width: 10em; display: none; max-width: 20em; top: auto; left: 0px; margin-left: 0px; margin-top: 0px;">
                                                                    <li class="dropdown-item level-1">
                                                                        <a href="/about-district" style="font-size: 14px;font-weight:600;">{{ __('HEADER_MENU_ABOUT_US_ABOUT') }}</a>
                                                                    </li>
                                                                    <li class="dropdown-item level-1">
                                                                        <a href="/hall-of-fame" style="font-size: 14px;font-weight:600;">{{ __('HEADER_MENU_ABOUT_US_HALL_OF_FAME') }}</a>
                                                                    </li>
                                                                    <li class="dropdown-item level-1">
                                                                        <a href="/organization-structure" style="font-size: 14px;font-weight:600;">{{ __('HEADER_MENU_ABOUT_US_ORGANIZATION') }}</a>
                                                                    </li>
                                                                    <li class="dropdown-item level-1">
                                                                        <a href="/senior-officers" style="font-size: 14px;font-weight:600;">{{ __('HEADER_MENU_ABOUT_US_SENIOR') }}</a>
                                                                    </li>
                                                                    <li class="dropdown-item level-1">
                                                                        <a href="/police-stations" style="font-size: 14px;font-weight:600;">{{ __('HEADER_MENU_ABOUT_US_STATIONS') }}</a>
                                                                    </li>
                                                                    <li class="dropdown-item level-1">
                                                                        <a href="/PDF/policeRank.e52e62bb.pdf" target="_blank" style="font-size: 14px;font-weight:600;">{{ __('HEADER_MENU_ABOUT_US_RANK') }}</a>
                                                                    </li>
                                                                    <li class="dropdown-item level-1">
                                                                        <a href="/PDF/policeFlags.bb53bb5f.pdf" target="_blank" style="font-size: 14px;font-weight:600;">{{ __('HEADER_MENU_ABOUT_US_FLAG') }}</a>
                                                                    </li>
                                                                </ul>
                                                            </li>
                                                            <li class="nav-item level-0 dropdown">
                                                                <a href="javascript:void(0);" class="nav-link has-submenu" id="sm-17149963338979644-5" aria-haspopup="true" aria-controls="sm-17149963338979644-6" aria-expanded="false" style="font-size: 14px;font-weight:600;">{{ __('HEADER_MENU_SPECIAL_UNIT') }}</a>
                                                                <ul class="dropdown-menu sm-nowrap" id="sm-17149963338979644-6" role="group" aria-hidden="true" aria-labelledby="sm-17149963338979644-5" aria-expanded="false" style="width: auto; min-width: 10em; display: none; max-width: 20em; top: auto; left: 0px; margin-left: 0px; margin-top: 0px;">
                                                                    <li class="dropdown-item level-1">
                                                                        <a href="/control-room" style="font-size: 14px;font-weight:600;">{{ __('HEADER_MENU_SPECIAL_UNIT_CONTROL_ROOM') }}</a>
                                                                    </li>
                                                                    <li class="dropdown-item level-1">
                                                                        <a href="/local-crime-branch" style="font-size: 14px;font-weight:600;">{{ __('HEADER_MENU_SPECIAL_UNIT_LCB') }}</a>
                                                                    </li>
                                                                    <li class="dropdown-item level-1">
                                                                        <a href="/district-special-branch" style="font-size: 14px;font-weight:600;">{{ __('HEADER_MENU_SPECIAL_UNIT_DSB') }}</a>
                                                                    </li>
                                                                    <li class="dropdown-item level-1">
                                                                        <a href="/cctns" style="font-size: 14px;font-weight:600;">{{ __('HEADER_MENU_SPECIAL_UNIT_CCTNS') }}</a>
                                                                    </li>
                                                                    <li class="dropdown-item level-1">
                                                                        <a href="/bdds" style="font-size: 14px;font-weight:600;">{{ __('HEADER_MENU_SPECIAL_UNIT_BDDS') }}</a>
                                                                    </li>
                                                                    <li class="dropdown-item level-1">
                                                                        <a href="/economic-offensive-wing" style="font-size: 14px;font-weight:600;">{{ __('HEADER_MENU_SPECIAL_UNIT_ECONOMIC') }}</a>
                                                                    </li>
                                                                    <li class="dropdown-item level-1">
                                                                        <a href="/traffic-branch" style="font-size: 14px;font-weight:600;">{{ __('HEADER_MENU_SPECIAL_UNIT_TRAFFIC_BRANCH') }}</a>
                                                                    </li>
                                                                </ul>
                                                            </li>
                                                            <li class="nav-item level-0 dropdown">
                                                                <a href="javascript:void(0);" class="nav-link has-submenu" id="sm-17149963338979644-11" aria-haspopup="true" aria-controls="sm-17149963338979644-12" aria-expanded="false" style="font-size: 14px;font-weight:600;">{{ __('HEADER_MENU_NEWS_UPDATES') }}</a>
                                                                <ul class="dropdown-menu" id="sm-17149963338979644-12" role="group" aria-hidden="true" aria-labelledby="sm-17149963338979644-11" aria-expanded="false">
                                                                    <li class="dropdown-item level-1">
                                                                        <a href="/press-release" style="font-size: 14px;font-weight:600;">{{ __('HEADER_MENU_NEWS_UPDATES_PRESS') }}</a>
                                                                    </li>
                                                                </ul>
                                                            </li>
                                                            <li class="nav-item level-0 dropdown">
                                                                <a href="javascript:void(0);" class="nav-link has-submenu" id="sm-17149963338979644-13" aria-haspopup="true" aria-controls="sm-17149963338979644-14" aria-expanded="false" style="font-size: 14px;font-weight:600;">{{ __('HEADER_MENU_CITIZEN_CHARTER') }}</a>
                                                                <ul class="dropdown-menu" id="sm-17149963338979644-14" role="group" aria-hidden="true" aria-labelledby="sm-17149963338979644-13" aria-expanded="false">
                                                                    <li class="dropdown-item level-1">
                                                                        <a href="/accident-detail-receipt" style="font-size: 14px;font-weight:600;">{{ __('HEADER_MENU_CITIZEN_CHARTER_ACCIDENT') }}</a>
                                                                    </li>
                                                                    <li class="dropdown-item level-1">
                                                                        <a href="/scheduled-cast-tribe" style="font-size: 14px;font-weight:600;">{{ __('HEADER_MENU_CITIZEN_CHARTER_OFFENCE_ACTS') }}</a>
                                                                    </li>
                                                                    <li class="dropdown-item level-1">
                                                                        <a href="/PDF/RTI_POINT_17.pdf" target="blank" style="font-size: 14px;font-weight:600;">{{ __('HEADER_MENU_CITIZEN_CHARTER_RIGHT_TO_INFORMATION') }}</a>
                                                                    </li>
                                                                    <li class="dropdown-item level-1">
                                                                        <a href="https://parivahan.gov.in/parivahan//en/content/act-rules-and-policies" class="external" target="_blank" style="font-size: 14px;font-weight:600;">{{ __('HEADER_MENU_CITIZEN_CHARTER_TRAFFIC_RULES') }}</a>
                                                                    </li>
                                                                    <li class="dropdown-item level-1">
                                                                        <a href="/PDF/Offence-Details-V13-ADG-Office.pdf" target="_blank" style="font-size: 14px;font-weight:600;">{{ __('HEADER_MENU_CITIZEN_CHARTER_TRAFFIC_FINES') }}</a>
                                                                    </li>
                                                                </ul>
                                                            </li>
                                                            <li class="nav-item level-0">
                                                                <a href="/photo-gallery" class="nav-link" data-target="#" style="font-size: 14px;font-weight:600;">{{ __('HEADER_MENU_PHOTO_GALLERY') }}</a>
                                                            </li>
                                                            <li class="nav-item level-0">
                                                                <a href="/contact-us" class="nav-link" data-target="#" style="font-size: 14px;font-weight:600;">{{ __('HEADER_MENU_CONTACT_US') }}</a>
                                                            </li>
                                                        </ul>
                                                    </nav>
                                                </div>
                                            </div>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <!-- <div class="topTicker" data-aos="fade-down" id="maincontent">
                <p>ठळक बातम्या</p>
                <marquee scrollamount="4">
                    @if(count($newsList))
                        @foreach($newsList as $detail)
                            <a @if($detail->MNW_Type == 2) href="{{ $detail->MNW_Link }}" @endif @if($detail->MNW_Type == 3) href="https://jalpanel.ssstest.in/{{ $detail->MNW_Link }}" target="_blank" @endif  title="{{ $detail->MNW_Title }}"><span>@if($detail->MNW_Type == 1) <i class="fa fa-bullhorn mr-2"></i> @endif @if($detail->MNW_Type == 2) <i class="fa fa-link mr-2"></i> @endif @if($detail->MNW_Type == 3) <i class="fa fa-file-pdf-o mr-2"></i> @endif{{ $detail->MNW_Title }}</span></a>
                        @endforeach
                    @endif
                </marquee>
            </div> -->
            <div class="container11">
                <div class="news_feed">
                    <div class="row">
                        <div class="col-lg-2 col-md-3 p-news">
                            <h2 class="newsfeed_label" tabindex="0">{{ __('HEADER_LATEST_NEWS') }}</h2>
                        </div>
                        <div class="col-lg-10 col-md-9">
                            <div class="region region-top-header-one">
                                <div class="views-element-container block block-views block-views-blockscrolling-messag-block-1" id="block-views-block-scrolling-messag-block-1-2">
                                    <div>
                                        <div class="view view-scrolling-messag view-id-scrolling_messag view-display-id-block_1 js-view-dom-id-5d068163e1f095338a00f759eae839d2df488bcd71fd7298784cb59a56561b22">
                                            <div class="view-content">
                                                <div class="news-ticker">
                                                    <div class="newslider bn-effect-scroll bn-direction-ltr" style="height: 40px; line-height: 38px; border-radius: 2px; border-width: 1px;">
                                                        <div class="bn-news" style="right: 90px;">
                                                            <ul style="width: 9336.28px; margin-left: -784px;">
                                                                @if(count($newsList))
                                                                    @foreach($newsList as $detail)
                                                                        <li>
                                                                            <a class="gif-icon" @if($detail->MNW_Type == 2) href="{{ $detail->MNW_Link }}" @endif @if($detail->MNW_Type == 3) href="{{ $detail->MNW_Link }}" target="_blank" @endif  title="{{ $detail->MNW_Title }}">@if($detail->MNW_Type == 1) <i class="fa fa-bullhorn mr-2"></i> @endif @if($detail->MNW_Type == 2) <i class="fa fa-link mr-2"></i> @endif @if($detail->MNW_Type == 3) <i class="fa fa-file-pdf-o mr-2"></i> @endif{{ $detail->MNW_Title }}</a>
                                                                        </li>
                                                                    @endforeach
                                                                @endif
                                                            </ul>
                                                        </div>
                                                        <div class="bn-controls"><button tabindex="0"><span class="bn-arrow bn-prev" tabindex="0"></span></button><button tabindex="0"><span class="bn-action bn-pause" tabindex="0"></span></button><button tabindex="0"><span class="bn-arrow bn-next" tabindex="0"></span></button></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="copyrightModal" class="modal">
                <div class="modal__inner">
                    <label for="3" onclick="closeModal()"><i class="fa fa-times m-14"></i></label>
                    <div class="modal-container">
                        <div class="modal-header">
                            <h2>Copyright Policy</h2>
                        </div>
                        <div class="modal-mainbody" id="cyberModalBody">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="doDonMain firstCh mt-3">
                                        <div class="doDonImg">
                                            <!-- <img src="{{ asset('images/correct.png') }}" alt="Do's for customers" aria-label="Do's for customers">-->
                                        </div>
                                        <h3 class="mb-4 font-weight-bold">Copyright policy (if the published information is available free of any charge)</h3>
                                        <ul class="list">
                                            <li>Information featured on this website can be re-published in any media form free of any charge only with prior permission from us or concerned respective authority which is owning the website, through email.</li>
                                            <li>Information can be republished as it is available and not to be used in a distorted or misleading manner.</li>
                                            <li>Where the material is being published or suggested to others, the source must be prominently acknowledged.</li>
                                            <li>However, the permission to reproduce this material does not extend to any material on this site, which is explicitly identified as being the copyright of a third party
                                            <br> Copyright policy (if there is a provision to reuse published information)
                                            <br>The information published on the website comes under copyright policy and obtaining authorization for their republish is a pre-requisite.
                                            <br>
                                            
                                            </li>
                                            
                                        </ul>
                                    </div>
                                    <!--  <div class="doDonMain mt-3">
                                        <div class="doDonImg">
                                            <img src="{{ asset('images/cancel.png') }}" alt="Don'ts for customers" aria-label="Don'ts for customers">
                                        </div>
                                        <h3 class="mb-4 font-weight-bold">Don’ts</h3>
                                        <ul class="list">
                                            <li>Never share debit card credentials &amp; UPI Pin with a third party</li>
                                        </ul>
                                    </div> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div id="securityModal" class="modal">
                <div class="modal__inner">
                    <label for="3" onclick="closeModal()"><i class="fa fa-times m-14"></i></label>
                    <div class="modal-container">
                        <div class="modal-header">
                            <h2>Security Policy</h2>
                        </div>
                        <div class="modal-mainbody" id="cyberModalBody">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="doDonMain firstCh mt-3">
                                        <div class="doDonImg">
                                            <!-- <img src="{{ asset('images/correct.png') }}" alt="Do's for customers" aria-label="Do's for customers">-->
                                        </div>
                                        <h3 class="mb-4 font-weight-bold">Security Policy</h3>
                                        <ul class="list">
                                            <li>For site security purposes and to ensure that this service remains available to all users, this Government computer system employs commercial software programs to monitor network traffic to identify unauthorized attempts to upload or change information, or otherwise cause damage.</li>
                                            <li>Except for authorized law enforcement investigations, no other attempts are made to identify individual users or their usage habits. Raw data logs are used for no other purposes and are scheduled for regular deletion.</li>
                                            <li> Unauthorized attempts to upload information or change information on this service are strictly prohibited and may be punishable under the Indian IT Act (2000).</li>
                                          
                                        </ul>
                                    </div>
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div id="termsModal" class="modal">
                <div class="modal__inner">
                    <label for="3" onclick="closeModal()"><i class="fa fa-times m-14"></i></label>
                    <div class="modal-container">
                        <div class="modal-header">
                            <h2>Security Policy</h2>
                        </div>
                        <div class="modal-mainbody" id="cyberModalBody">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="doDonMain firstCh mt-3">
                                        <div class="doDonImg">
                                            <!-- <img src="{{ asset('images/correct.png') }}" alt="Do's for customers" aria-label="Do's for customers">-->
                                        </div>
                                        <h3 class="mb-4 font-weight-bold">Security Policy</h3>
                                        <ul class="list">
                                            <li>The concerned department does not guarantee the availability of linked pages at all times.</li>
                                            <li>If the user visits the information and collects information or downloads files, the following elements may automatically download,
                                            <br>- Your service domain, IP number, how visitors accessed our website.
                                            <br>- browsers and operating systems.
                                            <br>- date and time of users’ visits.
                                            <br>- URLs from which visitors accessed information.
                                            <br>- if the user has visited the website from other websites, details of that website
                                            
                                            </li>
                                            
                                          
                                        </ul>
                                    </div>
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>