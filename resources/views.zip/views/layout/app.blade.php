@include("layout.css_link")
@include("layout.header")

@yield("page")

@include("layout.footer")
@include("layout.js_link")